package com.example.myapplication;

import android.graphics.drawable.Drawable;

public class ReviewData {
    public Drawable r_icon;
    public String r_name;
    public String r_date;
    public String r_review;
}
