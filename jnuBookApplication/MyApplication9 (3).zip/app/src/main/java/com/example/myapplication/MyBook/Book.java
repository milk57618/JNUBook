package com.example.myapplication.MyBook;

/**
 * Created by ming on 2018-06-07.
 */


class Book {
    private int b_id;
    private String b_name;
    private String lect_name;
    private int major_id;
    private int grade;
    private String title;
    private String content;
    private int state;
    private int user_id;
    private String post_date;
    private String image_path;
    private int price;

    public Book() {
        content = "diiidi";
        price = 1;
    }

    public Book(int b_id, String b_name, String lect_name, int major_id, int grade, String title, String Content, int state, int user_id, String post_date, int price){
        this.b_id = b_id;
        this.b_name = b_name;
        this.lect_name = lect_name;
        this.major_id = major_id;
        this.grade = grade;
        this.title = title;
        this.content = Content;
        this.state = state;
        this.user_id =user_id;
        this.post_date =post_date;
        this.price =price;
        this.image_path = "";
    }
    public int getB_id() {
        return b_id;
    }
    public void setB_id(int b_id) {
        this.b_id = b_id;
    }
    public String getB_name() {
        return b_name;
    }
    public void setB_name(String b_name) {
        this.b_name = b_name;
    }
    public String getLect_name() {
        return lect_name;
    }
    public void setLect_name(String lect_name) {
        this.lect_name = lect_name;
    }
    public int getMajor_id() {
        return major_id;
    }
    public void setMajor_id(int major_id) {
        this.major_id = major_id;
    }
    public int getGrade() {
        return grade;
    }
    public void setGrade(int grade) {
        this.grade = grade;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public int getState() {
        return state;
    }
    public void setState(int state) {
        this.state = state;
    }
    public int getUser_id() {
        return user_id;
    }
    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
    public String getPost_date() {
        return post_date;
    }
    public void setPost_date(String post_date) {
        this.post_date = post_date;
    }
    public String getImage_path() {
        return image_path;
    }
    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
}